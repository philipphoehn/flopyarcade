# game settings
envType = '1'
games = 50
episodes = 1000				# number of game episodes (i.e. user interventions)
flagSavePlot = False
flagManualControl = True
flagRenderAgent = False
flagPlayLoop = True
seedCrossValidation = 9999
pathMF2005 = None			# string of local path to MODFLOW 2005 executable
pathMP6 = None				# string of local path to MODPATH 6 executable
agentModel = 'agentDQNtest8___2500ep__970.5max__407.5avg____0.0min20200108202302datetime' # None


if envType == '1'
	from FloPyArcade import FloPyEnv as FloPyEnv
if envType == '2'
	from FloPyArcade import FloPyEnv2 as FloPyEnv
if envType == '3'
	from FloPyArcade import FloPyEnv3 as FloPyEnv
from FloPyArcade import FloPyAgent
from FloPyArcade import FloPyArcade
from numpy.random import randint, seed


if __name__ == '__main__':
	game = FloPyArcade(pathMF2005, pathMP6,
					   episodes, flagSavePlot, flagManualControl,
					   agentModel
					   )

	humanRewards = []
	doneAlready = 50

	seed(seedCrossValidation)
	seedsCV = randint(seedCrossValidation, size=games+doneAlready)

	for run in range(games):
		# seedCV = seedsCV[run]
		seedCV = seedsCV[run+doneAlready]
		print('game #:', run+1)
		game.play(envType=envType, render=flagRenderAgent, seed=seedCV)
		humanRewards.append(game.rewardTotal)
		if flagPlayLoop == False:
			if game.success == True:
				break
	print(humanRewards)