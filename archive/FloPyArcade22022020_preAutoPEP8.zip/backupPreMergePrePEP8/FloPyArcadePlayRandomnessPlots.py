# game settings
envType = '1'
games = 500
episodes = 1000				# number of game episodes (i.e. user interventions)
flagSavePlot = False
flagManualControl = True
flagRenderAgent = False
flagManualControl = False
pathMF2005 = None			# string of local path to MODFLOW 2005 executable
pathMP6 = None				# string of local path to MODPATH 6 executable
seed = 1

if envType == '1'
	from FloPyArcade import FloPyEnv as FloPyEnv
if envType == '2'
	from FloPyArcade import FloPyEnv2 as FloPyEnv
if envType == '3'
	from FloPyArcade import FloPyEnv3 as FloPyEnv
from FloPyArcade import FloPyAgent
from FloPyArcade import FloPyArcade
import numpy as np


if __name__ == '__main__':
	game = FloPyArcade(pathMF2005, pathMP6,
					   episodes, flagSavePlot, flagManualControl
					   )

	np.random.seed(seed)
	seedsCV = np.random.randint(200000, size=games)

	idxs = []
	rewards = []
	rewardsAverages = []
	import matplotlib.pyplot as plt
	for run in range(games):
		print('game #:', run+1)
		game.play(envType=envType, seed=seedsCV[run], render=flagRenderAgent)
		idxs.append(run+1)
		rewards.append(game.rewardTotal)
		rewardsAverages.append(np.mean(rewards))
		plt.scatter(idxs, rewardsAverages, s=2)
		plt.plot(idxs, rewardsAverages, lw=1)
		plt.xlim(left=0, right=games)
		plt.ylim(bottom=0, top=1000.)
		plt.xlabel('games')
		plt.ylabel('reward')
		plt.tight_layout()
		plt.savefig('C:\\FloPyArcade' + '\\temp\\' + 'randomRewardsAverages.png')