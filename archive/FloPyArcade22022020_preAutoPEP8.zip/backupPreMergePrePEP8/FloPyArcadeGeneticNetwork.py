# environment settings
envSettings = {
			   'envType': '1',							# string defining environment
			   'modelName': 'agentGenetic1mp2e-2n1024',	# string as model basename
			   'pathMF2005': None,						# string of local path to MODFLOW 2005 executable
			   'pathMP6': None,							# string of local path to MODPATH 6 executable
			   'seed': 1,								# integer enabling reproducibility
			   'agentsParallel': 16,					# integer defining parallelized agent runs
			   'render': False,							# boolean to define if displaying runs
			   'renderEvery': 1000						# integer defining runs displayed
			   }

# hyperparameters
hyParams = {
			'numAgents': 1024,							# integer defining number of agents
			'numAgentEpisodes': 200,					# integer defining number of episodes per agent
			'generations': 100,							# integer defining number of generations for evolution
			'nElitesConsidered': 100,					# integer defining number of top agents considered as parents
			'mutationPower': 0.02,						# 0.02 after https://arxiv.org/pdf/1712.06567.pdf
			'unitsLayer1': 500,							# integer
			'unitsLayer2': 500,							# integer
			'activationLayer1': 'relu',					# string
			'activationLayer2': 'relu',					# string
			'dropoutLayer1': 0.0,						# float
			'dropoutLayer2': 0.0,						# float
			'flagBatchNormalization': False,			# boolean
			'averagingRuns': 10,						# integer defining number of games played for averaging
			'rewardMin': 0.0  							# float defining minimal reward to save a model
			}


import numpy as np
import keras.backend.tensorflow_backend as backend
from keras.models import Sequential, clone_model
from keras.layers import Dense, Dropout, Conv2D, MaxPooling2D, Activation, Flatten
from keras.optimizers import Adam
from keras.callbacks import TensorBoard
import tensorflow as tf
# from collections import deque
# import time
# import random
# from tqdm import tqdm
import argparse
import os
import sys
# if envSettings['envType'] == '1':
from FloPyArcade import FloPyEnv as FloPyEnv
# elif envSettings['envType'] == '2':
# 	from FloPyArcade import FloPyEnv2 as FloPyEnv
# elif envSettings['envType'] == '3':
# 	from FloPyArcade import FloPyEnv3 as FloPyEnv
from FloPyArcade import FloPyAgent


def main(envSettings, hyParams):
	# initializing environment
	env = FloPyEnv(envSettings['envType'], envSettings['pathMF2005'], envSettings['pathMP6'],
				   modelName=envSettings['modelName'])

	# initializing agent
	agent = FloPyAgent(env.observationsVector, env.actionSpace, hyParams, envSettings, 'genetic')
	agent.GPUAllowMemoryGrowth()

	# running genetic search algorithm
	agent.runGenetic(env)


# !!! check whether generated environment is really unique
# !!! cross-validation dataset
# !!! needs a folder per agent in parallelized mode
# !!! seeds for keras initialization also important
# !!! currently, the rewards are not representative of generalizing agents
# !!! needs to look at average reward on large and similar dataset (no crossvalidation here)
# ??? why the memory increase? due to agents?
# ??? why is there negative reward?
# !!! try using one of the agents already "produced"
# !!! try resuming from weights of previously good model
# ??? try hyperparameter tuning?

# For more repetitive results
# np.random.seed(seed)
# tf.set_random_seed(seed)


if __name__ == '__main__':
	main(envSettings, hyParams)