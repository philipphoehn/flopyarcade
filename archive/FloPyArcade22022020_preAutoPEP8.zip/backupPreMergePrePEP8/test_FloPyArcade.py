import FloPyArcadePlay
import FloPyArcadeDQN
import FloPyArcadeGeneticNetwork
import unittest


class TestFloPyEnv1Play(unittest.TestCase):

	def test_FloPyEnvPlay_noExceptionRaised(self):
		"""Test a run of every existing environment."""
		
		failed = []
		for i in range(1,4):
			raised = False
			try:
				from FloPyArcadePlay import envSettings, gameSettings
				envSettings['envType'] = str(i)
				envSettings['flagSavePlot'] = False
				envSettings['flagManualControl'] = False
				envSettings['flagRenderAgent'] = False
				gameSettings['games'] = 1
				gameSettings['episodes'] = 2
				gameSettings['agentModel'] = 'unittestAgent'
				FloPyArcadePlay.main(envSettings, gameSettings)
				print('Successfully tested environment FloPyEnv' + str(i) + '.')
			except Exception as e:
				raised = True
				failed.append(i)
				print(e)
		for i in failed:
			self.assertFalse(raised, 'FloPyEnv' + str(i) + ' failed.')


class TestFloPyAgentDQN(unittest.TestCase):

	def test_FloPyAgentDQN_noExceptionRaised(self):
		"""Test an agent using the deep Q-Learning algorithm on a
		computationally simple case.
		"""

		raised = False
		try:
			from FloPyArcadeDQN import envSettings, hyParams
			# environment settings
			envSettings['envType'] = '1'
			envSettings['modelName'] = 'unittest'
			envSettings['render'] = False
			# hyperparameters
			hyParams['episodes'] = 4
			hyParams['numAgentEpisodes'] = 3
			hyParams['discount'] = 0.99
			hyParams['replayMemorySize'] = 10000
			hyParams['replayMemorySizeMin'] = 3
			hyParams['minibatchSize'] = 3
			hyParams['updateTargetEvery'] = 1
			hyParams['unitsLayer1'] = 5
			hyParams['unitsLayer2'] = 5
			hyParams['learningRate'] = 0.0001
			hyParams['epsilon'] = 1.0
			hyParams['epsilonDecay'] = 0.99975
			hyParams['epsilonMin'] = 0.005
			hyParams['crossvalidateEvery'] = 2
			hyParams['crossvalidateRuns'] = 2
			FloPyArcadeDQN.main(envSettings, hyParams)
			print('Successfully tested deep Q-network agent.')
		except Exception as e:
			raised = True
			print('debug error DQN', e)
		self.assertFalse(raised, 'Deep Q-network agent test failed.')


class TestFloPyAgentGenetic(unittest.TestCase):

	def test_FloPyAgentGenetic_noExceptionRaised(self):
		"""Test the genetic algorithm on a computationally simple case."""

		raised = False
		try:
			from FloPyArcadeGeneticNetwork import envSettings, hyParams
			# environment settings
			envSettings['envType'] = '1'
			envSettings['modelName'] = 'unittest'
			envSettings['agentsParallel'] = 2
			envSettings['render'] = False
			# hyperparameters
			hyParams['numAgents'] = 2
			hyParams['numAgentEpisodes'] = 2
			hyParams['generations'] = 2
			hyParams['nElitesConsidered'] = 2
			hyParams['mutationPower'] = 0.02
			hyParams['unitsLayer1'] = 5
			hyParams['unitsLayer2'] = 5
			hyParams['averagingRuns'] = 2
			FloPyArcadeGeneticNetwork.main(envSettings, hyParams)
			print('Successfully tested genetic agent.')
		except Exception as e:
			raised = True
			print(e)
		self.assertFalse(raised, 'Genetic agent test failed')


if __name__== '__main__':
	unittest.main()