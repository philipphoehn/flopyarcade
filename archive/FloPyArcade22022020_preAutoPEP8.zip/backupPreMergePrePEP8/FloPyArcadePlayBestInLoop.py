# game settings
envType = '1'
episodes = 1000				# number of game episodes (i.e. user interventions)
flagSavePlot = False
flagManualControl = False
flagRenderAgent = True
pathMF2005 = None			# string of local path to MODFLOW 2005 executable
pathMP6 = None				# string of local path to MODPATH 6 executable



from FloPyArcade import FloPyArcade
import glob
import os


if __name__ == '__main__':
	finished = False
	run = 0
	while finished == False:
		
		# finding current best-performing model
		wrkspc = os.path.dirname(os.path.abspath(__file__))
		models = glob.glob(os.path.join(wrkspc, 'models', '*h5'))
		agentModel = models[0]
		maxReward = 0
		for model in models:
			reward = float(model.split('avg_')[0].split('_')[-1])
			if reward > maxReward:
				maxReward = reward
				agentModel = model.split('\\')[-1].replace('.h5', '')
		game = FloPyArcade(pathMF2005, pathMP6,
						   episodes, flagSavePlot, flagManualControl,
						   agentModel
						   )

		print('game #:', run+1, 'model', agentModel)
		game.play(envType=envType, render=flagRenderAgent)
		run += 1