# environment settings
envSettings = {
			   'envType': '3',
			   'pathMF2005': None,			# string of local path to MODFLOW 2005 executable
			   'pathMP6': None,				# string of local path to MODPATH 6 executable
			   'flagSavePlot': False,
			   'flagManualControl': True,
			   'flagRenderAgent': False
			   }
gameSettings = {
				'games': 10,
				'episodes': 1000,
				'agentModel': 'agentDQNseed15_LR0-000025_units750_512',
			    }


from FloPyArcade import FloPyArcade


def main(envSettings, gameSettings):
	game = FloPyArcade(envSettings['pathMF2005'], envSettings['pathMP6'],
					   gameSettings['episodes'], envSettings['flagSavePlot'], envSettings['flagManualControl'],
					   gameSettings['agentModel']
					   )

	for run in range(gameSettings['games']):
		print('game #:', run+1)
		game.play(envType=envSettings['envType'], render=envSettings['flagRenderAgent'])
		if game.done == True:
			if game.success == True:
				break


if __name__ == '__main__':
	main(envSettings, gameSettings)