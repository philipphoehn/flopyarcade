# environment settings
envSettings = {
			   'envType': '1',
			   'modelName': 'unittest',		# 'agentDQNseed15_LR0-000025_units750_512'
			   'pathMF2005': None,			# string of local path to MODFLOW 2005 executable
			   'pathMP6': None,				# string of local path to MODPATH 6 executable
			   'seed': 15,
			   'seedCrossValidation': 1,
			   'render': False,
			   'renderEvery': 1000
			   }

# hyperparameters
hyParams = {
			'episodes': 20000,				# number of games played
			'numAgentEpisodes': 200,		# number of episodes per game
			'discount': 0.99,
			'replayMemorySize': 100000,  	# number of last steps kept for training
			'replayMemorySizeMin': 512,		# minimum required number of steps to start training
			'minibatchSize': 512,  			# number of samples (i.e. steps) used for training
			'updateTargetEvery': 5, 		# Terminal states (end of episodes)
			'unitsLayer1': 750,
			'unitsLayer2': 750,
			'activationLayer1': 'relu',
			'activationLayer2': 'relu',
			'dropoutLayer1': 0.2,
			'dropoutLayer2': 0.2,
			'flagBatchNormalization': False,
			'learningRate': 0.000025,
			'epsilon': 1.0,					# exploration fraction, going to be decayed
			'epsilonDecay': 0.99975,
			'epsilonMin': 0.005,
			'crossvalidateEvery': 250,		# 500 number of games before cross-validation
			'crossvalidateRuns': 200,		# 200 games played during cross-validation
			'rewardMin': 0  				# For model save
			}


import argparse
import os
import sys
from FloPyArcade import FloPyArcade
from FloPyArcade import FloPyAgent
from FloPyArcade import FloPyEnv


def main(envSettings, hyParams):
	# initializing environment
	env = FloPyEnv(envSettings['envType'], envSettings['pathMF2005'], envSettings['pathMP6'],
				   modelName=envSettings['modelName']
				   )

	print('env', env)

	# initializing agent
	agent = FloPyAgent(env.observationsVector, env.actionSpace, hyParams, envSettings, 'DQN')
	actionSpace = agent.actionSpace
	agent.GPUAllowMemoryGrowth()

	# running training of DQN agent
	agent.runDQN(env)


if __name__ == '__main__':
	main(envSettings, hyParams)