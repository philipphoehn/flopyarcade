from FloPyArcade import FloPyEnv
from FloPyArcade import FloPyAgent
from FloPyArcade import FloPyArcade


# game settings
episodes = 1000				# number of game episodes (i.e. user interventions)
flagSavePlot = False
flagManualControl = True
games = 500
pathMF2005 = None			# string of local path to MODFLOW 2005 executable
pathMP6 = None				# string of local path to MODPATH 6 executable
seed = 1


import numpy as np
flagManualControl = False
game = FloPyArcade(pathMF2005, pathMP6,
				   episodes, flagSavePlot, flagManualControl
				   )

np.random.seed(seed)
seedsCV = np.random.randint(200000, size=games)

idxs = []
rewards = []
rewardsAverages = []
import matplotlib.pyplot as plt
for run in range(games):
	print('game #:', run+1)
	game.play(seed=seedsCV[run])
	idxs.append(run+1)
	rewards.append(game.rewardTotal)
	rewardsAverages.append(np.mean(rewards))
	plt.scatter(idxs, rewardsAverages, s=2)
	plt.plot(idxs, rewardsAverages, lw=1)
	plt.xlim(left=0, right=games)
	plt.ylim(bottom=0, top=1000.)
	plt.xlabel('games')
	plt.ylabel('reward')
	plt.tight_layout()
	plt.savefig('C:\\FloPyArcade' + '\\temp\\' + 'randomRewardsAverages.png')