import numpy as np
import keras.backend.tensorflow_backend as backend
from keras.models import Sequential, clone_model
from keras.layers import Dense, Dropout, Conv2D, MaxPooling2D, Activation, Flatten
from keras.optimizers import Adam
from keras.callbacks import TensorBoard
import tensorflow as tf
# from collections import deque
# import time
# import random
# from tqdm import tqdm
import os
from FloPyArcade import FloPyEnv
from FloPyArcade import FloPyAgent
from FloPyArcade import FloPyArcade


class ModifiedTensorBoard(TensorBoard):
	# Own Tensorboard class

	def __init__(self, **kwargs):
		# Overriding init to set initial step and writer (we want one log file for all .fit() calls)
		super().__init__(**kwargs)
		self.step = 1
		self.writer = tf.summary.FileWriter(self.log_dir)


	def set_model(self, model):
		# Overriding this method to stop creating default log writer
		pass


	def on_epoch_end(self, epoch, logs=None):
		# Overrided, saves logs with our step number
		# (otherwise every .fit() will start writing from 0th step)
		self.update_stats(**logs)


	def on_batch_end(self, batch, logs=None):
		# Overrided, saves logs with our step number
		# (otherwise every .fit() will start writing from 0th step)
		pass


	def on_train_end(self, _):
		# Overrided, so won't close writer
		pass


	def update_stats(self, **stats):
		# Custom method for saving own metrics
		# Creates writer, writes custom metrics and closes writer
		self._write_logs(stats, self.step)


	def update_replay_memory(self, transition):
		# Adds step's data to a memory replay array
		# (observation space, action, reward, new observation space, done)
		self.replay_memory.append(transition)


def gpuAllowMemoryGrowth():
	from keras.backend.tensorflow_backend import set_session
	config = tf.ConfigProto()
	config.gpu_options.allow_growth = True
	sess = tf.Session(config=config)
	set_session(sess)


def create_model():
	model = Sequential()
	model.add(Dense(units=1500,
					input_shape=np.shape(env.observationsVector), use_bias=True))
	# kernel_initializer=load_initializer(kernelinitializer, hypparams, seed),
	# bias_initializer=load_initializer(biasinitializer, hypparams, seed)))
	model.add(Activation('relu'))
	model.add(Dropout(0.2))
	model.add(Dense(2000))
	model.add(Activation('relu'))
	model.add(Dropout(0.2))
	model.add(Dense(env.actionSpaceSize, activation='linear'))  # ACTION_SPACE_SIZE = how many choices (9)
	model.compile(loss="mse", optimizer=Adam(lr=0.001), metrics=['accuracy'])

	# use Xavier uniform instead?

	return model


# Queries main network for Q values given current observation space (environment state)
def get_qs(model, state):
	return model.predict(np.array(state).reshape(-1, (*np.shape(state))))[0]


def runAgentsGenetic(agents, env):
	
	reward_agents = []
	actionSpace = ['up', 'keep', 'down']

	
	for agent in agents:

		env.reset()
	
		# ??? what is this? needs replacement with Keras model
		# agent.eval()

		r=0
		s=0

		# !!! can this be parallelized?
		for _ in range(numAgentEpisodes):
			
			model = create_model()


			current_state = env.observationsVector

			# !!! needs replacement


			# actionIdx = np.argmax(agent.get_qs(model, current_state))
			actionIdx = np.argmax(get_qs(model, current_state))
			action = actionSpace[actionIdx]
			
			new_observation, reward, done, info = env.step(env.observationsVector, action, r)
			r=r+reward
			
			s=s+1
			observation = new_observation

			if(done):
				break

		reward_agents.append(r)		
		
	return reward_agents


def runAgentsRepeatedlyGenetic(agents, n, env):

	reward_agents = np.zeros(len(agents))
	for _ in range(n):
		reward_agents = np.add(reward_agents, runAgentsGenetic(agents, env))
	reward_agents = np.divide(reward_agents, n)

	return reward_agents


def averageScoreGenetic(agent, runs):
	score = 0.
	for i in range(runs):
		score += runAgentsGenetic([agent], env)[0]
	score = score/runs

	return score


def randomAgentsGenetic(numAgents):
	
	agents = []
	for _ in range(numAgents):
		
		agent = create_model()
					
		agents.append(agent)
		
	return agents


def returnChildrenGenetic(agents, sorted_parent_indexes, elite_index):

	children_agents = []

	#first take selected parents from sorted_parent_indexes and generate N-1 children
	for i in range(len(agents)-1):

		selected_agent_index = sorted_parent_indexes[np.random.randint(len(sorted_parent_indexes))]
		children_agents.append(mutateGenetic(agents[selected_agent_index]))

	#now add one elite
	elite_child = addEliteGenetic(agents, sorted_parent_indexes, elite_index)
	children_agents.append(elite_child)
	elite_index=len(children_agents)-1 #it is the last one

	return children_agents, elite_index


def mutateGenetic(agent):

	child_agent = clone_model(agent)
	
	mutation_power = 0.02 # hyper-parameter, set from https://arxiv.org/pdf/1712.06567.pdf
	
	weights = child_agent.get_weights()
	paramIdx = 0
	for parameters in weights:
		weights[paramIdx] = np.add(parameters,
								   mutation_power * np.random.randn())
		paramIdx += 1
	child_agent.set_weights(weights)

	return child_agent


def addEliteGenetic(agents, sorted_parent_indexes, elite_index=None, only_consider_top_n=10):
	
	candidate_elite_index = sorted_parent_indexes[:only_consider_top_n]
	
	if(elite_index is not None):
		candidate_elite_index = np.append(candidate_elite_index,[elite_index])
		
	top_score = None
	top_elite_index = None
	
	for i in candidate_elite_index:
		score = averageScoreGenetic(agents[i],runs=5)
		print("Score for elite i ", i, " is ", score)
		
		if(top_score is None):
			top_score = score
			top_elite_index = i
		elif(score > top_score):
			top_score = score
			top_elite_index = i
			
	print("Elite selected with index ", top_elite_index, " and score", top_score)
	
	child_agent = clone_model(agents[top_elite_index])
	return child_agent


# environment settings
envSettings = {
			   'modelName': 'agentGenetic1',
			   'pathMF2005': None,			# string of local path to MODFLOW 2005 executable
			   'pathMP6': None,				# string of local path to MODPATH 6 executable
			   'seed': 1,
			   'render': False,
			   'showEvery': 1000
			   }

# hyperparameters
hyParams = {
			'numAgents': 20,				# number of agents
			'numAgentEpisodes': 20,			# number of episodes per agent
			'topLimit': 20,					# number of top agents considered as parents
			'generations': 1000,			# generations for evolution
			'eliteIndex': None,
			'unitsLayer1': 500,
			'unitsLayer2': 500,
			'activationLayer1': 'relu',
			'activationLayer2': 'relu',
			'dropoutLayer1': 0.2,
			'dropoutLayer2': 0.2,
			'flagBatchNormalization': False,
			'learningRate': 0.0001,
			'crossvalidateRuns': 200,		# games played during cross-validation
			'rewardMin': 200,  				# For model save
			}


# !!! check whether generated environment is really unique
# !!! cross-validation dataset
# !!! needs a folder per agent in parallelized mode
# !!! seeds for keras initialization also important

# For more repetitive results
# np.random.seed(seed)
# tf.set_random_seed(seed)


# initializing environment
env = FloPyEnv(pathMF2005, pathMP6, modelName)

# initializing agent
agent = FloPyAgent(env.observationsVector, hyParams, envSettings, 'genetic')

game_actions = env.actionSpaceSize
gpuAllowMemoryGrowth()

agents = randomAgentsGenetic(numAgents)

for generation in range(generations):

	# returning rewards of agents
	rewards = runAgentsRepeatedlyGenetic(agents, 3, env) # return average of 3 runs

	# sorting by rewards
	sorted_parent_indexes = np.argsort(rewards)[::-1][:topLimit] #reverses and gives top values (argsort sorts by ascending by default) https://stackoverflow.com/questions/16486252/is-it-possible-to-use-argsort-in-descending-order 
	
	# setting up an empty list as a children agents container
	children_agents, elite_index = returnChildrenGenetic(agents, sorted_parent_indexes, elite_index)

	print('dbg', 'generation', generation, 'rewards', rewards)

	# kill all agents, and replace them with their children
	agents = children_agents