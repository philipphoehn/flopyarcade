from FloPyArcade import FloPyEnv
from FloPyArcade import FloPyAgent
from FloPyArcade import FloPyArcade


# game settings
episodes = 1000				# number of game episodes (i.e. user interventions)
flagSavePlot = False
flagManualControl = True
games = 500
pathMF2005 = None			# string of local path to MODFLOW 2005 executable
pathMP6 = None				# string of local path to MODPATH 6 executable


game = FloPyArcade(pathMF2005, pathMP6,
				   episodes, flagSavePlot, flagManualControl
				   )

for run in range(games):
	print('game #:', run+1)
	game.play()
	if game.success == True:
		break