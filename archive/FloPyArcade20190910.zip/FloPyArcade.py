#!/usr/bin/python3
# -*- coding: utf-8 -*- 


# FloPy Arcade game

# Goal:   To advectively transport a particle
# 		  from West to East
# 		  while minimizing deviation from
#		  straightmost trajectory.
# Action: Adjustments to southern
#		  stream stage.

# author: Philipp Hoehn
# philipp.hoehn@univie.ac.at


from flopy.modflow import Modflow, ModflowWel, ModflowDis, ModflowBas
from flopy.modflow import ModflowLpf, ModflowOc, ModflowPcg
from flopy.utils import HeadFile, CellBudgetFile, PathlineFile
from flopy.modpath import Modpath, ModpathBas
from flopy.plot import PlotMapView
from matplotlib.cm import get_cmap
from matplotlib.pyplot import figure, Circle, show, waitforbuttonpress, cla
from matplotlib.pyplot import close
from numpy import linspace, sqrt, ones, zeros, extract, min, max, ceil, sum
from numpy import copy, float32, int32
from numpy.random import randint , uniform, seed
from os.path import dirname, abspath, exists, join
from os import listdir, makedirs, remove, rmdir
from sys import modules
from platform import system
from time import time, sleep

# imports only necessary for agents
# !!! temporary class-wide importing only for debugging?
# !!! to minimize compilation size for game
from collections import deque
from keras import backend as K
import keras.backend.tensorflow_backend as backend
from keras.models import Sequential, clone_model
from keras.layers import Dense, Dropout, Activation, BatchNormalization
from keras.optimizers import Adam
from keras.callbacks import TensorBoard
import numpy as np
import tensorflow as tf
from tqdm import tqdm
import random
import os


class FloPyAgent():
	"""Agent to navigate a spawned particle advectively through the aquifer
		environment and collect reward along the way.
	"""

	def __init__(self, observationsVector=None, hyParams=None, envSettings=None,
				 mode='random'
				 ):
		"""Constructor."""

		self.wrkspc = dirname(abspath(__file__))
		if 'library.zip' in self.wrkspc:
			# changing workspace in case of call from executable
			self.wrkspc = dirname(dirname(self.wrkspc))

		self.actionSpace = ['up', 'keep', 'down']
		self.actionSpaceSize = len(self.actionSpace)

		try:
			self.observationsVector = observationsVector
			self.hyParams = hyParams
			self.envSettings = envSettings
		except: pass

		try:
			self.seed = self.envSettings['seed']
			np.random.seed(self.seed)
			random.seed(self.seed)
			tf.set_random_seed(self.seed)
		except: pass

		if mode == 'DQN':
			self.initializeDQNAgent()

		if mode == 'genetic':
			self.initializeGeneticAgents()


	def initializeDQNAgent(self):
		"""Initialize Deep Q-Learning Agent."""

		# initializing main predictive model
		self.mainModel = self.createDQNmodel()

		# initializing target network model
		self.targetModel = self.createDQNmodel()
		self.targetModel.set_weights(self.mainModel.get_weights())

		# initializing array with last n steps for training
		self.replayMemory = deque(maxlen=self.hyParams['replayMemorySize'])

		# loading custom tensorboard object
		self.tensorboard = self.ModifiedTensorBoard(log_dir="logs/{}-{}".format(self.envSettings['modelName'], int(time())))

		# initializing counter for updates on target network
		self.targetUpdateCounter = 0


	def initializeGeneticAgents(self):
		"""Initialize genetic ensemble of agents."""

		self.agents = self.randomAgentsGenetic(self.hyParams['numAgents'])


	def runGenetic(self, env):
		

		self.env = env

		for generation in range(self.hyParams['generations']):
			self.generationGenetic = generation

			# returning rewards of agents
			n = 3		# repetitions
			self.rewards = self.runAgentsRepeatedlyGenetic(self.agents, n, env) # return average of 3 runs

			# sorting by rewards
			sorted_parent_indexes = np.argsort(self.rewards)[::-1][:self.hyParams['topLimit']] #reverses and gives top values (argsort sorts by ascending by default) https://stackoverflow.com/questions/16486252/is-it-possible-to-use-argsort-in-descending-order 
			
			# setting up an empty list as a children agents container
			children_agents, elite_index = self.returnChildrenGenetic(self.agents, sorted_parent_indexes, self.hyParams['eliteIndex'])

			# kill all agents, and replace them with their children
			agents = children_agents


	def createDQNmodel(self):

		model = Sequential()

		model.add(Dense(units=self.hyParams['unitsLayer1'],
						input_shape=np.shape(self.observationsVector), use_bias=True))
		if self.hyParams['flagBatchNormalization'] == True:
			model.add(BatchNormalization())
		model.add(Activation(self.hyParams['activationLayer1']))
		model.add(Dropout(self.hyParams['dropoutLayer1']))

		model.add(Dense(self.hyParams['unitsLayer2']))
		model.add(Activation(self.hyParams['activationLayer2']))
		if self.hyParams['flagBatchNormalization'] == True:
			model.add(BatchNormalization())
		model.add(Dropout(self.hyParams['dropoutLayer2']))

		model.add(Dense(self.actionSpaceSize, activation='linear'))
		model.compile(loss="mse", optimizer=Adam(lr=self.hyParams['learningRate']), metrics=['accuracy'])

		return model


	def updateReplayMemory(self, transition):
		# Adds step's data to a memory replay array
		# (observation space, action, reward, new observation space, done)
		self.replayMemory.append(transition)


	def updateReplayMemoryZeroReward(self, steps):
		for i in range(steps):
			# overwriting for zero reward
			self.replayMemory[-i][2] = 0.0


	def train(self, terminal_state, step):
		'''Trains main network every step during episode.'''

		# training only if certain number of samples is already saved
		if len(self.replayMemory) < self.hyParams['replayMemorySizeMin']:
			return

		# retrieving a subset of random samples from memory replay table
		minibatch = random.sample(self.replayMemory,
								  self.hyParams['minibatchSize']
								  )

		# https://github.com/keras-team/keras/issues/5427
		K.get_session().run(tf.global_variables_initializer())
		K.get_session().run(tf.local_variables_initializer())

		# retrieving current states from minibatch
		# then querying NN model for Q values
		current_states = np.array([transition[0] for transition in minibatch])
		current_qs_list = self.mainModel.predict(current_states)

		# retrieving future states from minibatch
		# then querying NN model for Q values
		# when using target network, query it, otherwise main network should be queried
		new_current_states = np.array([transition[3] for transition in minibatch])
		future_qs_list = self.targetModel.predict(new_current_states)
		# print('dbg worked')
		# time.sleep(5)

		X, y = [], []

		# enumerating batches
		for index, (current_state, action, reward, new_current_state, done) in enumerate(minibatch):

			# If not a terminal state, get new q from future states, otherwise set it to 0
			# almost like with Q Learning, but we use just part of equation here
			if not done:
				max_future_q = np.max(future_qs_list[index])
				new_q = reward + self.hyParams['discount'] * max_future_q
			else:
				new_q = reward

			# Update Q value for given state
			current_qs = current_qs_list[index]
			# print('debug action', action)
			current_qs[action] = new_q

			# And append to our training data
			X.append(current_state)
			y.append(current_qs)

		# Fit on all samples as one batch, log only on terminal state
		self.mainModel.fit(np.array(X), np.array(y),
					   batch_size=self.hyParams['minibatchSize'],
					   verbose=0, shuffle=False,
					   callbacks=[self.tensorboard] if terminal_state else None)

		# Update target network counter every episode
		if terminal_state:
			self.targetUpdateCounter += 1

		# If counter reaches set value, update target network with weights of main network
		if self.targetUpdateCounter > self.hyParams['updateTargetEvery']:
			self.targetModel.set_weights(self.mainModel.get_weights())
			self.targetUpdateCounter = 0


	def takeActionUpdateAndTrain(self, env):

		# retrieving initial state
		current_state = env.observationsVector

		# resetting counters prior to restarting episode
		self.episodeReward = 0
		self.episodeStep = 1
		done = False

		# iterating until episode ends
		while not done:

			# epsilon defines the fraction of random to queried actions
			if np.random.random() > self.hyParams['epsilon']:
				# retrieving action from Q table
				actionIdx = np.argmax(self.get_qs(current_state))
				action = self.actionSpace[actionIdx]
			else:
				# retrieving random action
				actionIdx = np.random.randint(0, self.actionSpaceSize)
				action = self.actionSpace[actionIdx]
			new_state, reward, done, info = env.step(env.observationsVector,
													 action, self.episodeReward)

			# transforming new continous state to new discrete state
			# and counting reward
			self.episodeReward += reward

			if self.envSettings['render']:
				if not episode % self.envSettings['showEvery']:
					env.render()

			# updating replay memory and training main network on on every step
			self.updateReplayMemory([current_state, actionIdx, reward, new_state, done])
			self.train(done, self.episodeStep)
			current_state = new_state
			self.episodeStep += 1


	def runDQN(self, env):

		# generating seeds to generate recurring cross-validation dataset with
		# simplifies judgement of training progress as random noise will be reduced
		# and results will be reproducible
		np.random.seed(1)
		seedsCV = np.random.randint(200000, size=self.hyParams['crossvalidateRuns'])
		np.random.seed(self.envSettings['seed'])

		episodeRewards = []
		# Iterating over episodes being played
		for episode in tqdm(range(1, self.hyParams['episodes'] + 1), ascii=True, unit='episodes'):

			# Update tensorboard step every episode
			self.tensorboard.step = episode

			# resetting environment
			env.reset()

			self.takeActionUpdateAndTrain(env)

			if env.success == True:
				self.episodeReward = self.episodeReward
			elif env.success == False:
				self.episodeReward = 0.0
				# overwriting rewards in memory to zero in case of lack of success
				self.updateReplayMemoryZeroReward(self.episodeStep)

			# !!!
			# It will be important to cross-validate on the same set
			# of models here to see if consistently learning or not
			# or will this lead to overfitting?
			# therefore also no training during cross-validation
			# because this way the reward on training data is reported
			# where is the step to train the target network?

			# Append episode reward to a list and log stats (every given number of episodes)
			episodeRewards.append(self.episodeReward)
			if not episode % self.hyParams['crossvalidateEvery']:# or episode == 1:

				# loop to cross-validate on unique set of crossvalidateEvery models
				episodeRewardsCrossValidation = []
				debugs_wellQ_CV = []
				actionsVal = []
				for episodeVal in range(self.hyParams['crossvalidateRuns']):
					seedCV = seedsCV[episodeVal]
					self.episodeReward = 0.0
					step = 0

					env.reset(_seed=seedCV)
					debugs_wellQ_CV.append(env.wellQ)

					current_state = env.observationsVector
					
					# Reset flag and start iterating until episode ends
					done = False

					while not done:
						
						# This part stays mostly the same, the change is to query a model for Q values
						actionIdx = np.argmax(self.get_qs(current_state))
						action = self.actionSpace[actionIdx]
						actionsVal.append(action)

						new_state, reward, done, info = env.step(env.observationsVector, action, self.episodeReward)

						# Transform new continous state to new discrete state and count reward
						self.episodeReward += reward

						if self.envSettings['render']:
							if not episode % self.envSettings['showEvery']:
								env.render()

						# Every step we update replay memory and train main network
						current_state = new_state
						step += 1

					if env.success == True:
						self.episodeReward = self.episodeReward
					elif env.success == False:
						self.episodeReward = 0.0

					episodeRewardsCrossValidation.append(self.episodeReward)

				average_reward = np.mean(episodeRewardsCrossValidation[-self.hyParams['crossvalidateEvery']:])
				min_reward = np.min(episodeRewardsCrossValidation[-self.hyParams['crossvalidateEvery']:])
				max_reward = np.max(episodeRewardsCrossValidation[-self.hyParams['crossvalidateEvery']:])
				self.tensorboard.update_stats(reward_avg=average_reward, reward_min=min_reward, reward_max=max_reward, epsilon=self.hyParams['epsilon'])

				# Save model, but only when min reward is greater or equal a set value
				print('episode', episode, 'average reward', average_reward, 'min reward', min_reward, 'max reward', max_reward)
				# print('last actions', actionsVal[-20:], 'epsilon', epsilon)
				print('mean wellQ CV', np.mean(debugs_wellQ_CV))
				print('uniques', np.unique(actionsVal))
				if average_reward >= self.hyParams['rewardMin']:
					modelName = self.envSettings['modelName']
					self.mainModel.save(os.path.join(self.wrkspc, f'models/{modelName}_{max_reward:_>7.1f}max{average_reward:_>7.1f}avg{min_reward:_>7.1f}min{int(time.time())}.model'))

			# decaying epsilon
			if self.hyParams['epsilon'] > self.hyParams['epsilonMin']:
				self.hyParams['epsilon'] *= self.hyParams['epsilonDecay']
				self.hyParams['epsilon'] = np.max([self.hyParams['epsilonMin'],
											   self.hyParams['epsilon']])


	def runAgentsGenetic(self, agents, env):
		
		reward_agents = []
		actionSpace = ['up', 'keep', 'down']

		self.agentCount = 0
		for agent in agents:

			env.reset()
		
			# ??? what is this? needs replacement with Keras model
			# agent.eval()

			r=0
			s=0

			# !!! can this be parallelized?
			for _ in range(self.hyParams['numAgentEpisodes']):
				
				self.modelGenetic = self.createDQNmodel()

				current_state = env.observationsVector

				actionIdx = np.argmax(self.get_qsGenetic(current_state))
				action = actionSpace[actionIdx]
				
				new_observation, reward, done, info = env.step(env.observationsVector, action, r)
				r += reward
				
				s += 1
				observation = new_observation

				if(done):
					break

			reward_agents.append(r)	
			print('generation', self.generationGenetic+1, 'agent', self.agentCount+1, 'rewards', r)
			self.agentCount += 1

		return reward_agents


	def runAgentsRepeatedlyGenetic(self, agents, n, env):

		reward_agents = np.zeros(len(agents))
		for _ in range(n):
			reward_agents = np.add(reward_agents, self.runAgentsGenetic(agents, env))
		reward_agents = np.divide(reward_agents, n)

		return reward_agents


	def averageScoreGenetic(self, agent, runs):

		score = 0.
		for i in range(runs):
			score += self.runAgentsGenetic([agent], self.env)[0]
		score = score/runs

		return score


	def randomAgentsGenetic(self, num_agents):
		
		agents = []
		for _ in range(num_agents):
			agent = self.createDQNmodel()
			agents.append(agent)
			
		return agents


	def returnChildrenGenetic(self, agents, sorted_parent_indexes, elite_index):

		children_agents = []

		#first take selected parents from sorted_parent_indexes and generate N-1 children
		for i in range(len(agents)-1):

			selected_agent_index = sorted_parent_indexes[np.random.randint(len(sorted_parent_indexes))]
			children_agents.append(self.mutateGenetic(agents[selected_agent_index]))

		#now add one elite
		elite_child = self.addEliteGenetic(agents, sorted_parent_indexes, elite_index)
		children_agents.append(elite_child)
		elite_index=len(children_agents)-1 #it is the last one

		return children_agents, elite_index


	def mutateGenetic(self, agent):

		child_agent = clone_model(agent)
		
		mutation_power = 0.02 # hyper-parameter, set from https://arxiv.org/pdf/1712.06567.pdf
		
		weights = child_agent.get_weights()
		paramIdx = 0
		for parameters in weights:
			weights[paramIdx] = np.add(parameters,
									   mutation_power * np.random.randn())
			paramIdx += 1
		child_agent.set_weights(weights)

		return child_agent


	def addEliteGenetic(self, agents, sorted_parent_indexes, elite_index=None, only_consider_top_n=10):
		
		candidate_elite_index = sorted_parent_indexes[:only_consider_top_n]
		
		if(elite_index is not None):
			candidate_elite_index = np.append(candidate_elite_index,[elite_index])
			
		top_score = None
		top_elite_index = None
		
		for i in candidate_elite_index:
			score = self.averageScoreGenetic(agents[i],runs=5)
			print("Score for elite i ", i, " is ", score)
			
			if(top_score is None):
				top_score = score
				top_elite_index = i
			elif(score > top_score):
				top_score = score
				top_elite_index = i
				
		print("Elite selected with index ", top_elite_index, " and score", top_score)
		
		child_agent = clone_model(agents[top_elite_index])
		return child_agent


	def get_qs(self, state):
		# Queries main network for Q values given current observation space (environment state)
		return self.mainModel.predict(np.array(state).reshape(-1, (*np.shape(state))))[0]

	def get_qsGenetic(self, state):
		# Queries main network for Q values given current observation space (environment state)
		return self.modelGenetic.predict(np.array(state).reshape(-1, (*np.shape(state))))[0]


	def getActionSpace(self):
		"""Retrieve a list of performable actions."""

		return self.actionSpace


	def getAction(self, mode='random', keyPressed=None):
		"""Retrieve a choice of action.

		Either the action is determined from the player pressing a button or
		chosen randomly. If the player does not press a key within the given
		timeframe for an episode, the action remains unchanged.
		"""

		if mode == 'manual':
			if keyPressed in ['up', 'down']:
				self.action = keyPressed
			else:
				self.action = 'keep'
		if mode == 'random':
			actionIdx = randint(0, high=len(self.actionSpace))
			self.action = self.actionSpace[actionIdx]
		
		return self.action


	def GPUAllowMemoryGrowth(self):
		import tensorflow as tf
		from keras.backend.tensorflow_backend import set_session
		config = tf.ConfigProto()
		config.gpu_options.allow_growth = True
		sess = tf.Session(config=config)
		set_session(sess)


	# Memory fraction, used mostly when training multiple agents
	# memoryFraction = 0.20
	# gpu_options = tf.GPUOptions(per_process_gpu_memoryFraction=memoryFraction)
	# backend.set_session(tf.Session(config=tf.ConfigProto(gpu_options=gpu_options)))


	class ModifiedTensorBoard(TensorBoard):
		# custom Tensorboard class

		def __init__(self, **kwargs):
			# Overriding init to set initial step and writer (we want one log file for all .fit() calls)
			super().__init__(**kwargs)
			self.step = 1
			self.writer = tf.summary.FileWriter(self.log_dir)


		def set_model(self, model):
			# Overriding this method to stop creating default log writer
			pass


		def on_epoch_end(self, epoch, logs=None):
			# Overrided, saves logs with our step number
			# (otherwise every .fit() will start writing from 0th step)
			self.update_stats(**logs)


		def on_batch_end(self, batch, logs=None):
			# Overrided
			# We train for one batch only, no need to save anything at epoch end
			pass


		def on_train_end(self, _):
			# Overrided, so won't close writer
			pass


		def update_stats(self, **stats):
			# Custom method for saving own metrics
			# Creates writer, writes custom metrics and closes writer
			self._write_logs(stats, self.step)


		def get_qs(self, state):
			# Queries main network for Q values given current observation space (environment state)
			return self.model.predict(np.array(state).reshape(-1, *state.shape))[0]


class FloPyEnv():
	"""Environment to perform forward simulation using MODFLOW and MODPATH.
	
	On first call initializes a model with a randomly-placed operating well,
	initializes the corresponding steady-state flow solution as a starting state
	and initializes a random starting action and a random particle on the
	Western side.

	On a calling a step, it loads the current state, tracks the particle's
	trajectory through the model domain and returns the environment's new state,
	the new particle location as an observation and a flag if the particle has
	reached the operating well or not as a state.
	"""


	def __init__(self, pathMF2005=None, pathMP6=None, modelName='FloPyArcade',
				 _seed=None
				 ):
		"""Constructor."""

		self.modelName = modelName
		self.pathMF2005 = pathMF2005
		self.pathMP6 = pathMP6

		self.wrkspc = dirname(abspath(__file__))
		if 'library.zip' in self.wrkspc:
			# changing workspace in case of call from executable
			self.wrkspc = dirname(dirname(self.wrkspc))

		# setting up the model path
		self.modelpth = join(self.wrkspc, 'models', modelName)
		# ensuring modelpth directory exists
		if not exists(self.modelpth):
			makedirs(self.modelpth)

		# general environment settings,
		# like model domain and grid definition
		# currently fails with arbitray model extents?
		# why is a periodLength of 2.0 necessary to simulate 1 day?
		self.minX = 0.											# unit [m]
		self.minY = 0.											# unit [m]
		self.extentX = 100.										# unit [m]
		self.extentY = 100.										# unit [m]
		self.zTop = 50.											# unit [m]
		self.zBot = 0.											# unit [m]
		self.nLay = 1
		self.nRow = 100
		self.nCol = 100
		self.nVer = 1
		self.headSpecWest = 10.0								# unit [m]
		self.headSpecEast = 6.0									# unit [m]
		self.minQ = -3000.0										# unit [m3 d-1]
		self.maxQ = -500.0										# unit [m3 d-1]
		self.wellSpawnBufferXWest = 50.0
		self.wellSpawnBufferXEast = 20.0
		self.wellSpawnBufferY = 20.0
		self.minH = 6.0											# unit [m]
		self.maxH = 12.0										# unit [m]
		self.periods = 1
		self.periodLength = 2.0									# unit [d]
		self.periodSteps = 5
		self.periodSteadiness = True
		self.maxSteps = 300
		self.headsEvery = 2

		self.dRow = self.extentX/self.nCol						# unit [m]
		self.dCol = self.extentY/self.nRow						# unit [m]
		self.dVer = (self.zTop - self.zBot) / self.nLay			# unit [m]
		self.botM = linspace(self.zTop, self.zBot, self.nLay + 1)

		self.wellRadius = sqrt((2*self.dCol)**2 + (2*self.dRow)**2)
		
		self.actionRange = 5.0

		self.rewardMax = 1000
		self.distanceMax = 97.9
		self.deviationPenaltyFactor = 4.0

		self._seed = _seed
		if self._seed != None:
			seed(self._seed)

		self.timeStep = 0
		self.keyPressed = None
		self.initializeSimulators(pathMF2005, pathMP6)
		self.initializeAction(self.minH, self.maxH)
		self.initializeParticle()
		self.initializeModel()
		self.initializeWell(self.minQ, self.maxQ)

		self.reward = 0.

		# initializing trajectories container for potential plotting
		self.trajectories = {}
		self.trajectories['x'] = []
		self.trajectories['y'] = []
		self.trajectories['z'] = []

		# running MODFLOW to determine steady-state solution as a starting state
		self.runMODFLOW()

		self.state = {}
		self.state['heads'] = self.heads
		self.state['actionValue'] = self.actionValue
		self.observations = {}
		self.observations['particleCoords'] = self.particleCoords
		self.observations['heads'] = self.heads[0::self.headsEvery,
												0::self.headsEvery,
												0::self.headsEvery]
		self.observations['wellQ'] = self.wellQ
		self.observations['wellCoords'] = self.wellCoords

		self.observationsVector = self.observationsDictToVector(self.observations)

		self.comments = ''
		self.done = False


	def reset(self, _seed=None):
		self.__init__(self.pathMF2005, self.pathMP6, self.modelName, _seed=_seed)


	def step(self, observations, action, rewardCurrent,
			 flagSavePlot=False, flagManualControl=False
			 ):
		"""Perform single step of forwards simulation."""


		self.timeStep += 1
		self.keyPressed = None
		self.periodSteadiness = False

		self.actionValue = self.getActionValue(self.actionValue, action)

		observations = self.observationsVectorToDict(observations)
		self.particleCoordsBefore = observations['particleCoords']

		self.flagSavePlot = flagSavePlot
		self.flagManualControl = flagManualControl
		self.manualControlTime = 0.1
		self.rewardCurrent = rewardCurrent

		if self.timeStep > 1:
			# correcting for different reading order
			# why is this necessary?
			self.particleCoords[0] = self.extentX - self.particleCoords[0]

		if self._seed != None:
			seed(self._seed)

		self.initializeState(self.state)
		self.updateModel()
		self.updateWell()

		self.runMODFLOW()
		self.runMODPATH()
		self.evaluateParticleTracking()

		# calculating episode reward
		self.reward = self.calculateEpisodeReward(self.trajectories)

		self.state = {}
		self.state['heads'] = self.heads
		self.state['actionValue'] = self.actionValue
		del(self.observations)
		self.observations = {}
		self.observations['particleCoords'] = copy(self.particleCoordsAfter)
		self.observations['heads'] = self.heads[0::self.headsEvery,
												0::self.headsEvery,
												0::self.headsEvery]
		self.observations['wellQ'] = self.wellQ
		self.observations['wellCoords'] = self.wellCoords

		if self.observations['particleCoords'][0] >= self.extentX-self.dCol:
			self.success = True
		else:
			self.success = False

		self.observationsVector = self.observationsDictToVector(self.observations)

		# checking if particle is within horizontal distance of well
		dx = self.particleCoords[0]-self.wellCoords[0]
		# why would the correction for Y coordinate be necessary
		dy = self.extentY-self.particleCoords[1]-self.wellCoords[1]
		self.distanceWellParticle = sqrt(dx**2 + dy**2)
		if self.distanceWellParticle <= self.wellRadius:
			self.done = True
			self.reward = rewardCurrent * (-1.0)

		# checking if particle has reached eastern boundary
		if self.particleCoordsAfter[0] >= self.extentX-self.dCol:
			self.done = True

		# checking if particle has returned to western boundary
		if self.extentX-self.particleCoordsAfter[0] < self.minX+self.dCol:
			self.done = True
			self.reward = rewardCurrent * (-1.0)
		
		# checking if particle has reached southern boundary
		if self.particleCoordsAfter[1] <= self.minY+self.dRow:
			self.done = True
			self.reward = rewardCurrent * (-1.0)

		# aborting game if a threshold of steps have been taken
		if self.timeStep == self.maxSteps:
			self.done = True

		self.info = ''

		if flagSavePlot == True or flagManualControl == True:
			self.plotSimulation()

		# necessary to remove these file handles to release file locks
		del self.mf, self.cbb, self.hdobj
		if self.done == True:
			for f in listdir(self.modelpth):
				# removing files in folder
				remove(join(self.modelpth, f))
			if exists(self.modelpth):
				# removing folder with model files after run
				rmdir(self.modelpth)

		return self.observationsVector, self.reward, self.done, self.info


	def initializeSimulators(self, pathMF2005=None, pathMP6=None):
		"""Initialize simulators depending on operating system.

		Executables have to be specified or located in simulators subfolder.
		"""

		# setting name of MODFLOW and MODPATH executables
		if system() == 'Windows':
			if pathMF2005 == None:
				self.exe_name = join(self.wrkspc, 'simulators',
											 'MF2005.1_12', 'bin', 'mf2005'
											 ) + '.exe'
			elif pathMF2005 != None:
				self.exe_name = pathMF2005
			if pathMP6 == None:
				self.exe_mp = join(self.wrkspc, 'simulators',
										   'modpath.6_0', 'bin', 'mp6'
										   ) + '.exe'
			elif pathMP6 != None:
				self.exe_mp += pathMP6
		elif system() == 'Linux':
			if pathMF2005 == None:
				self.exe_name = join(self.wrkspc, 'simulators', 'mf2005')
			elif pathMF2005 != None:
				self.exe_name = pathMF2005
			if pathMP6 == None:
				self.exe_mp = join(self.wrkspc, 'simulators', 'mp6')
			elif pathMP6 != None:
				self.exe_mp = pathMP6
		else:
			print('Operating system is unknown.')

		self.versionMODFLOW = 'mf2005'
		self.versionMODPATH = 'mp6'


	def initializeAction(self, minH, maxH):
		"""Initialize southern stream boundary condition randomly."""

		self.actionValue = uniform(minH, maxH)


	def initializeParticle(self):
		"""Initialize spawn of particle randomly.
		 
		 The particle will be placed on the Western border just east of the
		 Western stream with with buffer to boundaries.
		 """

		self.particleSpawnBufferY = 20.0
		self.particleX = self.extentX - 1.1 * self.dCol
		ymin = 0.0+self.particleSpawnBufferY
		ymax = self.extentY-self.particleSpawnBufferY
		self.particleY = uniform(ymin, ymax)
		self.particleZ = self.zTop
		self.particleCoords = [self.particleX, self.particleY, self.particleZ]


	def initializeModel(self):
		"""Initialize groundwater flow model."""

		self.constructingModel()


	def initializeWell(self, minQ, maxQ):
		"""Initialize well randomly in the aquifer domain within margins."""

		xmin = 0.0+self.wellSpawnBufferXWest
		xmax = self.extentX-self.wellSpawnBufferXEast
		self.wellX = uniform(xmin, xmax) # self.extentX
		ymin = 0.0+self.wellSpawnBufferY
		ymax = self.extentY-self.wellSpawnBufferY
		self.wellY = uniform(ymin, ymax)
		self.wellZ = self.zTop
		self.wellCoords = [self.wellX, self.wellY, self.wellZ]

		self.wellQ = uniform(minQ, maxQ)

		# determining layer, row and column corresponding to well location
		l, c, r = self.cellInfoFromCoordinates([self.wellX,
												self.wellY,
												self.wellZ]
												)

		self.wellCellLayer = l
		self.wellCellColumn = c
		self.wellCellRow = r

		# adding WEL package to the MODFLOW model
		lrcq = {0:[[l-1, r-1, c-1, self.wellQ]]}
		wel = ModflowWel(self.mf, stress_period_data=lrcq)


	def initializeState(self, state):
		"""Initialize aquifer hydraulic head with state from previous step."""

		self.heads = state['heads']


	def updateModel(self):
		"""Update model domain for transient simulation."""

		self.constructingModel()


	def updateWell(self):
		"""Update model to continue using well."""

		# adding WEL package to the MODFLOW model
		lrcq = {0:[[self.wellCellLayer-1,
					self.wellCellRow-1,
					self.wellCellColumn-1,
					self.wellQ]]}
		wel = ModflowWel(self.mf, stress_period_data=lrcq)


	def constructingModel(self):
		"""Construct the groundwater flow model used for the arcade game.

		Flopy is used as a MODFLOW wrapper for input file construction.

		A specified head boundary condition is situated on the western, eastern
		and southern boundary. The southern boundary condition can be modified
		during the game. Generally, the western and eastern boundaries promote
		groundwater to flow towards the west. To simplify, all model parameters
		and aquifer thickness is homogeneous throughout.
		"""

		# assigning model name and creating model object
		self.mf = Modflow(self.modelName, exe_name=self.exe_name,
										verbose=False
										)

		# changing workspace to model path
		# changed line 1065 in mbase.py to suppress console output
		self.mf.change_model_ws(new_pth=self.modelpth)

		# creating the discretization object
		if self.periodSteadiness == True:
			self.dis = ModflowDis(self.mf, self.nLay,
												self.nRow, self.nCol,
												delr=self.dRow, delc=self.dCol,
												top=self.zTop,
												botm=self.botM[1:],
												steady=self.periodSteadiness
												)
		elif self.periodSteadiness == False:
			self.dis = ModflowDis(self.mf, self.nLay,
												self.nRow, self.nCol,
												delr=self.dRow, delc=self.dCol,
												top=self.zTop,
												botm=self.botM[1:],
												steady=self.periodSteadiness,
												nper=self.periods,
												nstp=self.periodSteps,
												perlen=self.periodLength
												)

		# defining variables for the BAS package
		self.ibound = ones((self.nLay, self.nRow, self.nCol), dtype=int32)
		self.ibound[:, :-5, 0] = -1
		self.ibound[:, :-5, -1] = -1
		self.ibound[:, -1, 5:-5] = -1

		if self.periodSteadiness == True:
			self.strt = ones((self.nLay, self.nRow, self.nCol),
								 dtype=float32
								 )
		elif self.periodSteadiness == False:
			self.strt = self.heads
		self.strt[:, :-5, 0] = self.headSpecWest
		self.strt[:, :-5, -1] = self.headSpecEast
		self.strt[:, -1, 5:-5] = self.actionValue
		self.bas = ModflowBas(self.mf, ibound=self.ibound,
											strt=self.strt
											)

		# adding LPF package to the MODFLOW model
		self.lpf = ModflowLpf(self.mf, hk=10., vka=10., ipakcb=53)

		# why is this relevant for particle tracking?
		stress_period_data = {}
		for kper in range(self.periods):
			for kstp in range([self.periodSteps][kper]):
				stress_period_data[(kper, kstp)] = ['save head',
													'save drawdown',
													'save budget',
													'print head',
													'print budget'
													]

		# adding OC package to the MODFLOW model for output control
		oc = ModflowOc(self.mf,
									 stress_period_data=stress_period_data,
									 compact=True
									 )

		# adding PCG package to the MODFLOW model
		pcg = ModflowPcg(self.mf)


	def runMODFLOW(self):
		"""Execute forward groundwater flow simulation using MODFLOW."""

		# writing MODFLOW input files
		self.mf.write_input()

		# self.check = self.mf.check(verbose=False)

		# running the MODFLOW model
		self.successMODFLOW, self.buff = self.mf.run_model(silent=True)
		if not self.successMODFLOW:
			raise Exception('MODFLOW did not terminate normally.')

		# loading simulation heads
		self.fnameHeads = join(self.modelpth, self.modelName+'.hds')
		self.hdobj = HeadFile(self.fnameHeads)
		# is this the correct state picked?
		# shouldn't we pick the heads at a specific runtime?
		self.times = self.hdobj.get_times()
		self.heads = self.hdobj.get_data(totim=self.times[-1])

		# loading discharge data
		self.fnameBudget = join(self.modelpth, self.modelName+'.cbc')
		self.cbb = CellBudgetFile(self.fnameBudget)
		self.frf = self.cbb.get_data(text='FLOW RIGHT FACE')[0]
		self.fff = self.cbb.get_data(text='FLOW FRONT FACE')[0]


	def runMODPATH(self):
		"""Execute forward particle tracking simulation using MODPATH."""

		# creating MODPATH simulation object
		self.mp = Modpath(self.modelName, exe_name=self.exe_mp,
										modflowmodel=self.mf,
										model_ws=self.modelpth
										)

		self.mpbas = ModpathBas(self.mp,
											  hnoflo=self.mf.bas6.hnoflo,
											  hdry=self.mf.lpf.hdry,
											  ibound=self.mf.bas6.ibound.array,
											  prsity=0.2,
											  prsityCB=0.2
											  )

		self.sim = self.mp.create_mpsim(trackdir='forward', simtype='pathline',
										packages='RCH')

		# writing MODPATH input files
		self.mp.write_input()

		# manipulating input file to contain custom particle location
		out = []
		keepFlag = True
		fIn = open(join(self.modelpth, self.modelName+'.mpsim'),
				   'r', encoding='utf-8')
		inLines = fIn.readlines()
		for line in inLines:
			if 'rch' in line:
				keepFlag = False
				out.append(self.modelName+'.mploc\n')
				# particle generation option 2
				# budget output option 3
				# TimePointCount (number of TimePoints)
				# is this ever respected?
				out.append(str(2) + '\n')
				# why does removing this work?
				del out[7]
				# TimePoints
				out.append('0.000000   1.000000\n')
			if keepFlag == True:
				out.append(line)
		fIn.close()

		# writing particle tracking settings to file
		fOut = open(join(self.modelpth, self.modelName+'.mpsim'),
					'w')
		for line in range(len(out)):
			if 'mplst' in out[line]:
				_ = u'2   1   2   1   1   2   2   3   1   1   1   1\n'
				out[line+1] = _
			fOut.write(out[line])
		fOut.close()

		# determining layer, row and column corresponding to particle location
		l, c, r = self.cellInfoFromCoordinates(self.particleCoords)
		
		# determining fractions of current cell to represent particle location
		# in MODPATH input file, with fracCol coordinate correction being
		# critical.
		fracCol = 1.0 - ((self.particleCoords[0] / self.dCol)
						 - ((c-1)*self.dCol)
						 )
		fracRow = (self.particleCoords[1] / self.dRow) - ((r-1)*self.dRow)
		fracVer = (self.particleCoords[2] / self.dVer) - ((l-1)*self.dVer)

		# writing current particle location to file
		fOut = open(join(self.modelpth, self.modelName+'.mploc'),
					'w')
		fOut.write('1\n')
		fOut.write(u'1\n')
		fOut.write(u'particle\n')
		fOut.write(u'1\n')
		fOut.write(u'1 1 1' + u' ' + str(l) + u' ' + str(self.nRow-r+1) + u' '
				   + str(self.nCol-c+1) + u' ' + str('%.6f' % (fracCol)) + u' '
				   + str('%.6f' % fracRow) + u' ' + str('%.6f' % fracVer)
				   + u' 0.000000 ' + u'particle\n')
		# GroupName
		fOut.write('particle\n')
		# LocationCount, ReleaseStartTime, ReleaseOption
		fOut.write('1 0.000000 1\n')
		fOut.close()

		# running the MODPATH model
		self.mp.run_model(silent=True)


	def evaluateParticleTracking(self):
		"""Evaluate particle tracking results from MODPATH.

		Determines new particle coordinates after advective transport during the
		episode.
		"""
 
		# loading the pathline data
		self.pthfile = join(self.modelpth, self.mp.sim.pathline_file)
		self.pthobj = PathlineFile(self.pthfile)
		self.p0 = self.pthobj.get_data(partid=0)

		# filtering results to select appropriate timestep
		# why is it running for longer?
		self.particleTrajX = extract(self.p0['time'] <= self.periodLength,
										self.p0['x']
										)
		self.particleTrajY = extract(self.p0['time'] <= self.periodLength,
										self.p0['y']
										)
		self.particleTrajZ = extract(self.p0['time'] <= self.periodLength,
										self.p0['z']
										)

		self.trajectories['x'].append(self.particleTrajX)
		self.trajectories['y'].append(self.particleTrajY)
		self.trajectories['z'].append(self.particleTrajZ)

		self.particleCoordsAfter = [self.particleTrajX[-1],
									self.particleTrajY[-1],
									self.particleTrajZ[-1]
									]

		# changing current particle coordinate to new
		self.particleCoords = copy(self.particleCoordsAfter)


	def calculateEpisodeReward(self, trajectories):
		"""Calculate episode reward.

		Reward is a function of deviation from the straightmost path to the
		eastern boundary. The penalty for deviation is measured by the ratio
		between the length of the straightmost path along the x axis and the
		length of the actually traveled path.
		"""

		x = trajectories['x'][-1]
		y = trajectories['y'][-1]

		lengthShortest = x[-1] - x[0]
		lengthActual = self.calculatePathLength(x, y)

		# this ratio defines the fraction of the highest possible reward
		if lengthActual != 0.:
			pathLengthRatio = lengthShortest/lengthActual
		elif lengthActual == 0.:
			pathLengthRatio = 1.0

		# reward for going backwards?

		distanceFraction = lengthShortest/self.distanceMax
		self.rewardMaxEpisode = (distanceFraction * self.rewardMax)
		# self.rewardMaxEpisode = (pathLengthRatio * self.rewardMax)
		# self.rewardMaxEpisode /= (self.deviationPenaltyFactor)**2
		self.episodeReward = self.rewardMaxEpisode * (pathLengthRatio**self.deviationPenaltyFactor)
		self.episodeReward = self.episodeReward

		if lengthShortest < 0.:
			# negative reward for traveling backwards
			self.episodeReward *= -1.0 * self.episodeReward

		# why is this necessary?
		if lengthActual == 0.:
			self.episodeReward = 0.

		return self.episodeReward


	def plotSimulation(self):
		"""Plot the simulation state at the current timestep.

		Displaying and/or saving the visualisation. The active display can take
		user input to control the southern boundary condition.
		"""

		# plotting the data
		if self.timeStep == 1:
			self.fig = figure(figsize=(10, 10))
			self.ax = self.fig.add_subplot(1, 1, 1, aspect='equal')
			self.ax2 = self.ax.twinx()
			self.ax2.axis('off')

		self.ax.set_xlim(left=self.minX, right=self.minX+self.extentX)
		self.ax.set_ylim(bottom=self.minY, top=self.minY+self.extentY)
		self.ax2.set_xlim(left=self.minX, right=self.minX+self.extentX)
		self.ax2.set_ylim(bottom=self.minY, top=self.minY+self.extentY)

		self.ax.set_xlabel('water level:   ' + str('%.2f' % self.actionValue) + ' m' + '\n\nAdjustable (up/down key)', fontsize=20)
		self.ax.set_ylabel('Start\n\nwater level:   ' + str('%.2f' % self.headSpecWest) + ' m', fontsize=20)
		self.ax2.set_ylabel('water level:   ' + str('%.2f' % self.headSpecEast) + ' m\n\nDestination', fontsize=20)

		self.ax.set_xticks([])
		self.ax.set_yticks([])
		self.ax2.set_xticks([])
		self.ax2.set_yticks([])

		self.modelmap = PlotMapView(model=self.mf, layer=0)
		
		cmap = get_cmap('terrain')
		self.grid = self.modelmap.plot_grid(zorder=1, lw=0.1)
		self.headsplot = self.modelmap.plot_array(self.heads,
												  masked_values=[999.],
												  alpha=0.5, zorder=2,
												  cmap=cmap
												  )
		self.quadmesh = self.modelmap.plot_ibound(zorder=3)
		self.quiver = self.modelmap.plot_discharge(self.frf, self.fff,
												   head=self.heads,
												   alpha=0.1, zorder=4
												   )

		# plotting well safety zone
		wellBufferCircle = Circle((self.wellX, self.extentY-self.wellY),
									  self.wellRadius,
									  edgecolor='r', facecolor=None, fill=False,
									  zorder=3, alpha=1.0, lw=2.0,
									  label='protection zone'
									  )
		self.ax2.add_artist(wellBufferCircle)

		# plotting 30 contour lines based on data
		self.levels = linspace(min(self.heads), max(self.heads), 30)
		self.extent = (self.dRow/2., self.extentX - self.dRow/2.,
					   self.extentY - self.dCol/2., self.dCol/2.
					   )
		self.contours = self.modelmap.contour_array(self.heads,
													levels=self.levels,
													alpha=0.5, zorder=4
													)

		self.ax2.text(self.wellX+3., self.extentY-self.wellY, str(int(self.wellQ)) + '\nm3/d',
					 fontsize=20, color='black'
					 )

		if self.done == True:
			if self.success == True:
				successString = 'You won.'
			elif self.success == False:
				successString = 'You lost.'
		elif self.done == False:
			successString = ''

		self.ax2.text(30, 70, successString,
					  fontsize=50, color='red', zorder=10
					  )

		timeString = '%.0f' % (float(self.timeStep)*(self.periodLength-1.0))
		self.ax.set_title('FloPy Arcade game'
						  + ', timestep '
						  + str(int(self.timeStep)) + '\n'
						  + '\nscore: '
						  + str(int(self.rewardCurrent))
						  + '     '
						  + timeString
						  + ' d elapsed',
						  fontsize=20
						  )

		# plotting ideal particle trajectory leading to maximum reward
		self.ax2.plot([self.minX, self.minX + self.extentX],
					 [self.particleY, self.particleY],
					 lw=1.5, c='white', linestyle='--', zorder=5, alpha=0.5
					 )

		# plotting particle trajectory
		countCoords = 0
		colorsLens = []
		for i in range(len(self.trajectories['x'])):
			countCoords += len(self.trajectories['x'][i])
			colorsLens.append(len(self.trajectories['x'][i]))
		colorsFadeAlphas = linspace(0.1, 1.0, countCoords)
		colorsRGBA = zeros((countCoords, 4))
		colorsRGBA[:,0] = 1.0
		colorsRGBA[:,3] = colorsFadeAlphas
		idxCount = 0

		for i in range(len(self.trajectories['x'])):
			self.ax2.plot(self.trajectories['x'][i], self.trajectories['y'][i],
						  lw=2, c=colorsRGBA[idxCount+colorsLens[i]-1,:], zorder=6
						  )
			idxCount += colorsLens[i]
		self.ax2.scatter(self.trajectories['x'][-1][-1], self.trajectories['y'][-1][-1],
						 lw=2, c='red', zorder=6
						 )

		# determining if called from IPython notebook
		if 'ipykernel' in modules:
			flagFromIPythonNotebook = True
		else:
			flagFromIPythonNotebook = False

		if self.flagManualControl == True:

			if flagFromIPythonNotebook == False:
				self.fig.canvas.mpl_connect('key_press_event', self.captureKeyPress)
				show(block=False)
				waitforbuttonpress(timeout=self.manualControlTime)

			if flagFromIPythonNotebook == True:
				# changing plotting updating or IPython notebooks
				from IPython import display
				display.clear_output(wait=True)
				display.display(self.fig)
				# need to capture key stroke here as well

		if self.flagSavePlot == True:
			# setting up the path to save results plots in
			self.plotspth = join(self.wrkspc, 'runs')
			# ensuring plotspth directory exists
			if not exists(self.plotspth):
				makedirs(self.plotspth)

			self.fig.savefig(join(self.wrkspc, 'runs',
										  'pathlines' + str(self.timeStep)
										  + '.png'
										  )
							 )

		self.ax.cla()
		self.ax2.cla()
		self.ax.clear()
		self.ax2.clear()


	def cellInfoFromCoordinates(self, coords):
		"""Determine layer, row and column corresponding to model location."""

		x = coords[0]
		y = coords[1]
		z = coords[2]

		layer = int(ceil((z + self.zBot)/self.dVer))
		column = int(ceil((x + self.minX)/self.dCol))
		row = int(ceil((y + self.minY)/self.dRow))

		return layer, column, row


	def calculatePathLength(self, x, y):
		"""Calculate length of advectively traveled path."""

		n = len(x)
		lv = []
		for i in range(n):
			if i > 0:
				lv.append(sqrt((x[i]-x[i-1])**2 + (y[i]-y[i-1])**2))
		pathLength = sum(lv)
		
		return pathLength


	def captureKeyPress(self, event):
		self.keyPressed = event.key


	def getActionValue(self, value, action):
		"""Retrieve a list of performable actions."""

		if action == 'up':
			self.actionValue = value + 0.1 * self.actionRange
		elif action == 'keep':
			self.actionValue = value
		elif action == 'down':
			self.actionValue = value - 0.1 * self.actionRange

		return self.actionValue


	def observationsDictToVector(self, observationsDict):
		HeadsSkip = 10
		observationsVector = []
		for obs in observationsDict['particleCoords']:
			observationsVector.append(obs)
		for obs in observationsDict['heads'].flatten().flatten()[0::HeadsSkip]:
			observationsVector.append(obs)
		observationsVector.append(observationsDict['wellQ'])
		for obs in observationsDict['wellCoords']:
			observationsVector.append(obs)
		return observationsVector


	def observationsVectorToDict(self, observationsVector):
		observationsDict = {}
		observationsDict['particleCoords'] = observationsVector[:3]
		observationsDict['heads'] = observationsVector[3:-5]
		observationsDict['wellQ'] = observationsVector[-4]
		observationsDict['wellCoords'] = observationsVector[:-3]
		return observationsDict


class FloPyArcade():
	"""Instance of a FLoPy arcade game.
	
	Initializes a game agent and environment. Then allows to play the game.
	"""


	def __init__(self, pathMF2005, pathMP6,
				 episodes, flagSavePlot, flagManualControl
				 ):
		"""Constructor."""

		self.pathMF2005 = pathMF2005
		self.pathMP6 = pathMP6
		self.episodes = episodes
		self.flagSavePlot = flagSavePlot
		self.flagManualControl = flagManualControl


	def play(self, env=None, seed=None):
		"""Play an instance of the Flopy arcade game."""

		t0 = time()

		# creating the agent
		agent = FloPyAgent()

		self.actionRange = 5.0
		self.actionSpace = ['up', 'keep', 'down']
	
		# creating the environment
		if env == None:
			env = FloPyEnv(self.pathMF2005, self.pathMP6, _seed=seed)
		observations, done = env.observationsVector, env.done

		# game loop
		self.rewardTotal = 0.
		for ep in range(self.episodes):

			if done == False:

				# without user control input: generating random agent action
				if self.flagManualControl == True:
					action = agent.getAction('manual', env.keyPressed)
				elif self.flagManualControl == False:
					action = agent.getAction('random')

				observations, reward, done, _ = env.step(observations,
														 action,
														 self.rewardTotal,
														 self.flagSavePlot,
														 self.flagManualControl
														 )

				self.rewardTotal += reward

			elif done == True:

				if self.flagManualControl == True:
					# freezing screen shortly when game is done
					sleep(5)

				self.success = env.success
				if env.success == True:
					successString = 'won'
				elif env.success == False:
					successString = 'lost'
					# total loss of reward if entering well protection zone
					self.rewardTotal = 0.0

				print('The game was ' + successString + ' after ' + str(ep)
					  + ' episodes.')
				close('all')
				break

		self.episodesPlayed = ep
		self.runtime = (time()-t0)/60.