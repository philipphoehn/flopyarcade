from collections import deque
import keras.backend.tensorflow_backend as backend
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation, BatchNormalization
from keras.optimizers import Adam
from keras.callbacks import TensorBoard
import numpy as np
import os
import tensorflow as tf
import time
from tqdm import tqdm
import random
from FloPyArcade import FloPyEnv
from FloPyArcade import FloPyAgent
from FloPyArcade import FloPyArcade


class DQNAgent:

	def __init__(self, observationsVector, actionSpaceSize):
		"""Constructor."""

		self.observationsVector = observationsVector
		self.actionSpaceSize = actionSpaceSize

		# initializing main predictive model
		self.model = self.create_model()
		
		# initializing target network model
		self.target_model = self.create_model()
		self.target_model.set_weights(self.model.get_weights())

		# initializing array with last n steps for training
		self.replay_memory = deque(maxlen=REPLAY_MEMORY_SIZE)

		# losding custom tensorboard object
		self.tensorboard = ModifiedTensorBoard(log_dir="logs/{}-{}".format(MODEL_NAME, int(time.time())))

		# counter for updates on target network
		self.target_update_counter = 0


	def create_model(self):
		model = Sequential()

		# not including activation on input layer
		model.add(Dense(units=500,
						input_shape=np.shape(self.observationsVector), use_bias=True))
		# kernel_initializer=load_initializer(kernelinitializer, hypparams, seed),
		# bias_initializer=load_initializer(biasinitializer, hypparams, seed)))
		model.add(BatchNormalization())
		model.add(Activation('relu'))
		model.add(Dropout(0.2))

		model.add(Dense(500))
		model.add(Activation('relu'))
		model.add(BatchNormalization())
		model.add(Dropout(0.2))

		model.add(Dense(env.actionSpaceSize, activation='linear'))  # ACTION_SPACE_SIZE = how many choices (9)
		model.compile(loss="mse", optimizer=Adam(lr=0.0001), metrics=['accuracy'])
		return model


	# Adds step's data to a memory replay array
	# (observation space, action, reward, new observation space, done)
	def update_replay_memory(self, transition):
		self.replay_memory.append(transition)

	def update_replay_memory_zeroreward(self, steps):
		for i in range(steps):
			# overwriting for zero reward
			self.replay_memory[-i][2] = 0.0


	# Trains main network every step during episode
	def train(self, terminal_state, step):

		# Start training only if certain number of samples is already saved
		if len(self.replay_memory) < MIN_REPLAY_MEMORY_SIZE:
			return

		# Get a minibatch of random samples from memory replay table
		minibatch = random.sample(self.replay_memory, MINIBATCH_SIZE)

		# Get current states from minibatch, then query NN model for Q values
		# current_states = np.array([transition[0] for transition in minibatch])/255
		current_states = np.array([transition[0] for transition in minibatch])
		current_qs_list = self.model.predict(current_states)

		# Get future states from minibatch, then query NN model for Q values
		# When using target network, query it, otherwise main network should be queried
		# new_current_states = np.array([transition[3] for transition in minibatch])/255
		new_current_states = np.array([transition[3] for transition in minibatch])
		future_qs_list = self.target_model.predict(new_current_states)

		X = []
		y = []

		# Now we need to enumerate our batches
		for index, (current_state, action, reward, new_current_state, done) in enumerate(minibatch):

			# If not a terminal state, get new q from future states, otherwise set it to 0
			# almost like with Q Learning, but we use just part of equation here
			if not done:
				max_future_q = np.max(future_qs_list[index])
				new_q = reward + DISCOUNT * max_future_q
			else:
				new_q = reward

			# Update Q value for given state
			current_qs = current_qs_list[index]
			# print('debug action', action)
			current_qs[action] = new_q

			# And append to our training data
			X.append(current_state)
			y.append(current_qs)

		# Fit on all samples as one batch, log only on terminal state
		self.model.fit(np.array(X), np.array(y), batch_size=MINIBATCH_SIZE, verbose=0, shuffle=False, callbacks=[self.tensorboard] if terminal_state else None)

		# Update target network counter every episode
		if terminal_state:
			self.target_update_counter += 1

		# If counter reaches set value, update target network with weights of main network
		if self.target_update_counter > UPDATE_TARGET_EVERY:
			self.target_model.set_weights(self.model.get_weights())
			self.target_update_counter = 0


	# Queries main network for Q values given current observation space (environment state)
	def get_qs(self, state):
		return self.model.predict(np.array(state).reshape(-1, (*np.shape(state))))[0]


# Own Tensorboard class
class ModifiedTensorBoard(TensorBoard):

	# Overriding init to set initial step and writer (we want one log file for all .fit() calls)
	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self.step = 1
		self.writer = tf.summary.FileWriter(self.log_dir)


	# Overriding this method to stop creating default log writer
	def set_model(self, model):
		pass


	# Overrided, saves logs with our step number
	# (otherwise every .fit() will start writing from 0th step)
	def on_epoch_end(self, epoch, logs=None):
		self.update_stats(**logs)


	# Overrided
	# We train for one batch only, no need to save anything at epoch end
	def on_batch_end(self, batch, logs=None):
		pass


	# Overrided, so won't close writer
	def on_train_end(self, _):
		pass


	# Custom method for saving own metrics
	# Creates writer, writes custom metrics and closes writer
	def update_stats(self, **stats):
		self._write_logs(stats, self.step)


	# Queries main network for Q values given current observation space (environment state)
	def get_qs(self, state):
		return self.model.predict(np.array(state).reshape(-1, *state.shape))[0]


def gpu_allowmemorygrowth():
	import tensorflow as tf
	from keras.backend.tensorflow_backend import set_session
	config = tf.ConfigProto()
	config.gpu_options.allow_growth = True
	sess = tf.Session(config=config)
	set_session(sess)


gpu_allowmemorygrowth()




wrkspc = 'C:\\FloPyArcade'
MODEL_NAME = 'agent1'
seed = 1

DISCOUNT = 0.99
REPLAY_MEMORY_SIZE = 100_000  # How many last steps to keep for model training
MIN_REPLAY_MEMORY_SIZE = 10000  # Minimum number of steps in memory to start training
MINIBATCH_SIZE = 5012  # 64 # How many steps (samples) to use for training
UPDATE_TARGET_EVERY = 25  # Terminal states (end of episodes)
MIN_REWARD = 200  # For model save
MEMORY_FRACTION = 0.20

# Environment settings
EPISODES = 20_000

# Exploration settings
epsilon = 1  # not a constant, going to be decayed
EPSILON_DECAY = 0.99975
MIN_EPSILON = 0.005

#  Stats settings
AGGREGATE_STATS_EVERY = 1000  # episodes
CV_RUNS = 200
SHOW_PREVIEW = False

# game settings
episodes = 1000				# number of game episodes (i.e. user interventions)
flagSavePlot = False
flagManualControl = True
games = 10
pathMF2005 = None			# string of local path to MODFLOW 2005 executable
pathMP6 = None				# string of local path to MODPATH 6 executable

actionSpace = ['up', 'keep', 'down']


env = FloPyEnv(pathMF2005, pathMP6, MODEL_NAME)


np.random.seed(1)
seedsCV = np.random.randint(200000, size=AGGREGATE_STATS_EVERY)

# For stats
ep_rewards = []


# For more repetitive results
random.seed(seed)
np.random.seed(seed)
tf.set_random_seed(seed)

# !
# Need to have the same set of testing games across training?
# show progress for single and generation of agents on a single
# generate gifs of progress on this during evokution
# !

# Memory fraction, used mostly when trai8ning multiple agents
#gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=MEMORY_FRACTION)
#backend.set_session(tf.Session(config=tf.ConfigProto(gpu_options=gpu_options)))


agent = DQNAgent(env.observationsVector, env.actionSpaceSize)

# Iterate over episodes
for episode in tqdm(range(1, EPISODES + 1), ascii=True, unit='episodes'):

	# Update tensorboard step every episode
	agent.tensorboard.step = episode

	# Restarting episode - reset episode reward and step number
	episode_reward = 0
	step = 1

	# Reset environment and get initial state
	env.reset()
	current_state = env.observationsVector

	# Reset flag and start iterating until episode ends
	done = False
	while not done:
		
		# This part stays mostly the same, the change is to query a model for Q values
		if np.random.random() > epsilon:
			# Get action from Q table
			actionIdx = np.argmax(agent.get_qs(current_state))
			action = actionSpace[actionIdx]
			# print('train: using q table')
		else:
			# Get random action
			actionIdx = np.random.randint(0, env.actionSpaceSize)
			action = actionSpace[actionIdx]
			# print('train: taking random action')
		new_state, reward, done, info = env.step(env.observationsVector, action, episode_reward)

		# Transform new continous state to new discrete state and count reward
		episode_reward += reward

		if SHOW_PREVIEW and not episode % AGGREGATE_STATS_EVERY:
			# !!!
			env.render()

		# Every step we update replay memory and train main network
		agent.update_replay_memory([current_state, actionIdx, reward, new_state, done])
		agent.train(done, step)
		current_state = new_state
		step += 1

	if env.success == True:
		episode_reward = episode_reward
	elif env.success == False:
		episode_reward = 0.0
		# !!! updating to zero reward
		agent.update_replay_memory_zeroreward(step)

	# !!!
	# It will be important to cross-validate on the same set
	# of models here to see if consistently learning or not
	# or will this lead to overfitting?
	# therefore also no training during cross-validation
	# because this way the reward on training data is reported
	# where is the step to train the target network?

	# Append episode reward to a list and log stats (every given number of episodes)
	ep_rewards.append(episode_reward)
	if not episode % AGGREGATE_STATS_EVERY:# or episode == 1:

		# loop to cross-validate on unique set of AGGREGATE_STATS_EVERY models
		ep_rewards_CV = []
		debugs_wellQ_CV = []
		actionsVal = []
		for episodeVal in range(CV_RUNS):
			seed = seedsCV[episodeVal]
			episode_reward = 0.0
			step = 0

			env.reset(_seed=seed)
			debugs_wellQ_CV.append(env.wellQ)

			current_state = env.observationsVector
			
			# Reset flag and start iterating until episode ends
			done = False

			while not done:
				
				# This part stays mostly the same, the change is to query a model for Q values
				actionIdx = np.argmax(agent.get_qs(current_state))
				action = actionSpace[actionIdx]
				actionsVal.append(action)

				new_state, reward, done, info = env.step(env.observationsVector, action, episode_reward)

				# Transform new continous state to new discrete state and count reward
				episode_reward += reward

				if SHOW_PREVIEW and not episode % AGGREGATE_STATS_EVERY:
					# !!!
					env.render()

				# Every step we update replay memory and train main network
				current_state = new_state
				step += 1

			if env.success == True:
				episode_reward = episode_reward
			elif env.success == False:
				episode_reward = 0.0

			ep_rewards_CV.append(episode_reward)

		average_reward = np.mean(ep_rewards_CV[-AGGREGATE_STATS_EVERY:])
		min_reward = np.min(ep_rewards_CV[-AGGREGATE_STATS_EVERY:])
		max_reward = np.max(ep_rewards_CV[-AGGREGATE_STATS_EVERY:])
		agent.tensorboard.update_stats(reward_avg=average_reward, reward_min=min_reward, reward_max=max_reward, epsilon=epsilon)

		# Save model, but only when min reward is greater or equal a set value
		print('episode', episode, 'average reward', average_reward, 'min reward', min_reward, 'max reward', max_reward)
		# print('last actions', actionsVal[-20:], 'epsilon', epsilon)
		print('mean wellQ CV', np.mean(debugs_wellQ_CV))
		print('uniques', np.unique(actionsVal))
		if average_reward >= MIN_REWARD:
			# !!!
			agent.model.save(os.path.join(wrkspc, f'models/{MODEL_NAME}_{max_reward:_>7.1f}max{average_reward:_>7.1f}avg{min_reward:_>7.1f}min{int(time.time())}.model'))

	# Decay epsilon
	if epsilon > MIN_EPSILON:
		epsilon *= EPSILON_DECAY
		epsilon = max(MIN_EPSILON, epsilon)