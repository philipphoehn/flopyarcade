import numpy as np
import keras.backend.tensorflow_backend as backend
from keras.models import Sequential, clone_model
from keras.layers import Dense, Dropout, Conv2D, MaxPooling2D, Activation, Flatten
from keras.optimizers import Adam
from keras.callbacks import TensorBoard
import tensorflow as tf
# from collections import deque
# import time
# import random
# from tqdm import tqdm
import os
from FloPyArcade import FloPyEnv
from FloPyArcade import FloPyAgent


# environment settings
envSettings = {
			   'modelName': 'agentGenetic1',
			   'pathMF2005': None,			# string of local path to MODFLOW 2005 executable
			   'pathMP6': None,				# string of local path to MODPATH 6 executable
			   'seed': 1,
			   'agentsParallel': 1,
			   'render': False,
			   'showEvery': 1000
			   }

# hyperparameters
hyParams = {
			'numAgents': 100,				# number of agents
			'numAgentEpisodes': 20,			# number of episodes per agent
			'topLimit': 10,					# number of top agents considered as parents
			'generations': 1000,			# generations for evolution
			'eliteIndex': None,
			'unitsLayer1': 500,
			'unitsLayer2': 500,
			'activationLayer1': 'relu',
			'activationLayer2': 'relu',
			'dropoutLayer1': 0.2,
			'dropoutLayer2': 0.2,
			'flagBatchNormalization': False,
			'learningRate': 0.0001,
			'crossvalidateRuns': 200,		# games played during cross-validation
			'rewardMin': 200,  				# For model save
			}


# !!! check whether generated environment is really unique
# !!! cross-validation dataset
# !!! needs a folder per agent in parallelized mode
# !!! seeds for keras initialization also important
# !!! currently, the rewards are not representative of generalizing agents
# !!! needs to look at average reward on large and similar dataset (no crossvalidation here)
# ??? why the memory increase? due to agents?
# ??? why is there negative reward?
# !!! try using one of the agents already "produced"
# !!! try resuming from weights of previously good model
# ??? try hyperparameter tuning?

# For more repetitive results
# np.random.seed(seed)
# tf.set_random_seed(seed)


# initializing environment
env = FloPyEnv(envSettings['pathMF2005'], envSettings['pathMP6'],
			   modelName=envSettings['modelName'])

# initializing agent
agent = FloPyAgent(env.observationsVector, hyParams, envSettings, 'genetic')
agent.GPUAllowMemoryGrowth()

agent.runGenetic(env)