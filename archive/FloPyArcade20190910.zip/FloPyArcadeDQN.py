from FloPyArcade import FloPyEnv
from FloPyArcade import FloPyAgent


# environment settings
envSettings = {
			   'modelName': 'agentDQN1',
			   'pathMF2005': None,			# string of local path to MODFLOW 2005 executable
			   'pathMP6': None,				# string of local path to MODPATH 6 executable
			   'seed': 5,
			   'render': False,
			   'showEvery': 1000
			   }

# hyperparameters
hyParams = {
			'episodes': 20000,				# number of games played
			'discount': 0.99,
			'replayMemorySize': 100000,  	# number of last steps kept for training
			'replayMemorySizeMin': 1000,	# minimum required number of steps to start training
			'minibatchSize': 128,  			# number of samples (i.e. steps) used for training
			'updateTargetEvery': 5, 		# Terminal states (end of episodes)
			'unitsLayer1': 500,
			'unitsLayer2': 500,
			'activationLayer1': 'relu',
			'activationLayer2': 'relu',
			'dropoutLayer1': 0.2,
			'dropoutLayer2': 0.2,
			'flagBatchNormalization': False,
			'learningRate': 0.0001,
			'epsilon': 1.0,					# exploration fraction, going to be decayed
			'epsilonDecay': 0.99975,
			'epsilonMin': 0.005,
			'crossvalidateEvery': 500,		# episodes
			'crossvalidateRuns': 200,		# games played during cross-validation
			'rewardMin': 200,  				# For model save
			}


# initializing environment
env = FloPyEnv(envSettings['pathMF2005'], envSettings['pathMP6'],
			   modelName=envSettings['modelName']
			   )

# initializing agent
agent = FloPyAgent(env.observationsVector, hyParams, envSettings, 'DQN')
actionSpace = agent.actionSpace
agent.GPUAllowMemoryGrowth()

# running training of DQN agent
agent.runDQN(env)